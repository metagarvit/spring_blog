package com.springboot.blog.controller;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.springboot.blog.entity.Category;
import com.springboot.blog.payload.CategoryDto;
import com.springboot.blog.repository.CategoryRepository;
import com.springboot.blog.repository.UserRepository;
import com.springboot.blog.security.CustomUserDetailsService;
import com.springboot.blog.security.JwtTokenProvider;
import com.springboot.blog.service.AuthService;
import com.springboot.blog.service.CategoryService;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
@MockitoSettings(strictness = Strictness.WARN)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class AuthControllerTest {
	
	MockMvc mockMvc;

	@Mock
	private AuthService authService;


	@InjectMocks
	private AuthController authController;

	CategoryDto categoryDto = CategoryDto.builder().id(1L).name("Testing").description("Testing Desc").build();
	Category category = Category.builder().id(1L).name("Testing").description("Testing Desc").build();

	@BeforeAll
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(authController) .build();
	}

}
